#!/bin/bash
#ec2ip
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/EC2-setup.sh  ubuntu@$1:~/
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/Crawler-Master/crawler-master.war  ubuntu@$1:~/
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/Crawler-Worker/crawler-worker.war  ubuntu@$1:~/
#scp -pr -i ~/.ec2/CuriosityCrawler.pem ~/.aws/  ubuntu@$1:~/.aws/
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/host-map.ser  ubuntu@$1:~/
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/map.ser  ubuntu@$1:~/
#scp -i ~/.ec2/CuriosityCrawler.pem ~/Project/G10/SearchEngine/se.war  ubuntu@$1:~/
scp -i ~/.ec2/CuriosityCrawler.pem ~/scripts/big.txt ubuntu@$1:~/
scp -i ~/.ec2/CuriosityCrawler.pem ~/scripts/spell.py ubuntu@$1:~/
