#!/bin/bash
#sudo mkdir /root/.aws
#sudo mv .aws/credentials /root/.aws/
sudo apt-get update
sudo apt-get install openjdk-7-jre-headless
sudo apt-get update
sudo apt-get install openjdk-7-jdk
sudo apt-get update
sudo apt-get install jetty
sudo apt-get update
#sudo cp se.war /usr/share/jetty/webapps/ROOT.war
#cd /usr/share/jetty
#sudo java -jar start.jar
